import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';

import { consumeConfig } from '../../../core/react_components/ConfigUtils';

/**
 * Bank Info Form components which provide add/edit/delete functionality
 */
class Component_Name extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div>
        
      </div>
    );
  }
}

Component_Name.propTypes = {};

Component_Name.defaultProps = {};

export default connect(
  createStructuredSelector({}),
  {})(consumeConfig(Component_Name));
